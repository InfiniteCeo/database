--Create view 'AllGames':
/*
USE sports;
CREATE VIEW AllGames AS SELECT * FROM games;
*/


--Extract all records from 'AllGames' view:
/*
USE sports;
SELECT * FROM AllGames;
*/
--Extract details for Code 3 from the two tables (using views implicitly):
/*
USE sports;
SELECT * FROM games WHERE Code = 3;
SELECT * FROM duties WHERE Code = 3;
*/

--Extract records of athletics or basketball from games folder (using views implicitly):

/*
USE sports;
SELECT * FROM games WHERE Game = 'athletics' OR Game = 'basketball';
*/

--Rename a view (Example: Renaming 'AllGames' to 'CurrentGames'):

-- SQL Server specific syntax for renaming a view
/*
USE sports;
EXEC sp_rename 'AllGames', 'CurrentGames';
*/

--Drop a view (Example: Dropping 'CurrentGames' view):

/*
USE sports;
DROP VIEW CurrentGames;
*/
