--Create SQL DDL Queries (Alter, Drop, Truncate)


--Alter command (Add a column to 'games' table):

/*
USE sports;
ALTER TABLE games ADD Location VARCHAR(255);
*/


--Truncate command (Remove all data from 'duties' table, keeping structure):

/*
USE sports;
TRUNCATE TABLE duties;
*/


--Drop command (Remove 'duties' table completely):

/*
USE sports;
DROP TABLE duties;
*/


