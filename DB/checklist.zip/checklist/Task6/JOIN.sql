--Apply Right Join and Left Join to Database Tables

--using 'games' and 'duties' tables

/*

Assuming 'games' and 'duties' tables are populated as in Task 4, and 'Code' is the linking column.
Left Join example:
*/

USE sports;
SELECT g.Name, g.Game, d.title
FROM games g
LEFT JOIN duties d ON g.Code = d.Code;


--Right Join example:

/*
USE sports;
SELECT g.Name, g.Game, d.title
FROM games g
RIGHT JOIN duties d ON g.Code = d.Code;
*/


--Inner Join example (most common):

/*
USE sports;
SELECT g.Name, g.Game, d.title
FROM games g
INNER JOIN duties d ON g.Code = d.Code;
*/
