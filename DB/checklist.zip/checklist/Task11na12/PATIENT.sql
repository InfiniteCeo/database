--Create 'patient' database and use it:
CREATE DATABASE patient;
USE patient;


--Create 'pDetails' and 'pAilments' tables:

USE patient;
CREATE TABLE pDetails (patNo INT PRIMARY KEY, name VARCHAR(255), gender CHAR(1), residence VARCHAR(255), age INT);
CREATE TABLE pAilments (patNo INT, ailment VARCHAR(255), status VARCHAR(255), FOREIGN KEY (patNo) REFERENCES pDetails(patNo));


--Insert records into 'pDetails' and 'pAilments':

USE patient;
INSERT INTO pDetails (patNo, name, gender, residence, age) VALUES (4550, 'Neshe', 'M', 'Umoja', 34);
INSERT INTO pDetails (patNo, name, gender, residence, age) VALUES (4567, 'Mengo', 'F', 'Kajiado', 50);
INSERT INTO pDetails (patNo, name, gender, residence, age) VALUES (7894, 'Wira', 'F', 'Athi River', 45);
INSERT INTO pDetails (patNo, name, gender, residence, age) VALUES (5434, 'Elijah', 'F', 'Nakuru', 23);
INSERT INTO pDetails (patNo, name, gender, residence, age) VALUES (3233, 'Mawingu', 'M', 'Limuru', 12);

INSERT INTO pAilments (patNo, ailment, status) VALUES (4550, 'Malaria', 'severe');
INSERT INTO pAilments (patNo, ailment, status) VALUES (4567, 'Typhoid', 'Mild');
INSERT INTO pAilments (patNo, ailment, status) VALUES (7894, 'TB', 'Mild');
INSERT INTO pAilments (patNo, ailment, status) VALUES (5434, 'Malaria', 'severe');
INSERT INTO pAilments (patNo, ailment, status) VALUES (3233, 'TB', 'severe');


--Extract male patients from Umoja with Malaria:


USE patient;
SELECT p.name FROM pDetails p JOIN pAilments a ON p.patNo = a.patNo WHERE p.gender = 'M' AND p.residence = 'Umoja' AND a.ailment = 'Malaria';

--Extract female patients with Typhoid:

USE patient;
SELECT p.name FROM pDetails p JOIN pAilments a ON p.patNo = a.patNo WHERE p.gender = 'F' AND a.ailment = 'Typhoid';


--Extract patients with Malaria or Typhoid:

USE patient;
SELECT p.name FROM pDetails p JOIN pAilments a ON p.patNo = a.patNo WHERE a.ailment = 'Malaria' OR a.ailment = 'Typhoid';

--Extract patients with severe TB:


USE patient;
SELECT p.name FROM pDetails p JOIN pAilments a ON p.patNo = a.patNo WHERE a.ailment = 'TB' AND a.status = 'severe';

--Create an index on 'patNo' in 'pDetails' table:


USE patient;
CREATE INDEX idx_patNo ON pDetails (patNo);
