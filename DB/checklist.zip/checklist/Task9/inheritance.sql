--Inheritance with Object-Relational Mapping (ORM):


-- Example for TPH: Person and subclasses Student, Employee
/*
CREATE TABLE Persons (
    Id INT PRIMARY KEY,
    Name VARCHAR(255),
    Discriminator VARCHAR(50), -- 'Student' or 'Employee'
    EnrollmentDate DATE,      -- Student specific
    HireDate DATE             -- Employee specific
);
*/

-- Example for TPT: Person, Student, Employee
CREATE TABLE Persons (
    Id INT PRIMARY KEY,
    Name VARCHAR(255)
);

CREATE TABLE Students (
    Id INT PRIMARY KEY,
    EnrollmentDate DATE,
    FOREIGN KEY (Id) REFERENCES Persons(Id)
);

CREATE TABLE Employees (
    Id INT PRIMARY KEY,
    HireDate DATE,
    FOREIGN KEY (Id) REFERENCES Persons(Id)
);
