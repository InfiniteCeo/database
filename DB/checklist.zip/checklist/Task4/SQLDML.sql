--Create SQL DML Queries (Select, Insert, Delete, Update)NB### UNCOMMENT TO WORK


--Create 'sports' database and 'games' table

/*
CREATE DATABASE sports;
USE sports;
CREATE TABLE games (Code INT, Name VARCHAR(255), Game VARCHAR(255), gender CHAR(1));
*/


--Insert records into 'games'table
/*
USE sports;
INSERT INTO games (Code, Name, Game, gender) VALUES (1, 'Mesh', 'athletics', 'm');
INSERT INTO games (Code, Name, Game, gender) VALUES (2, 'Rod', 'football', 'f');
INSERT INTO games (Code, Name, Game, gender) VALUES (3, 'Lim', 'basketball', 'm');
INSERT INTO games (Code, Name, Game, gender) VALUES (4, 'Lon', 'table tennis', 'f');
INSERT INTO games (Code, Name, Game, gender) VALUES (5, 'Tin', 'restling', 'f');
*/

--Create 'duties' table

/*
USE sports;
CREATE TABLE duties (Code INT, Institution VARCHAR(255), title VARCHAR(255));
*/

--Insert records into 'duties' table

/*
USE sports;
INSERT INTO duties (Code, Institution, title) VALUES (1, 'Nima', 'Coach');
INSERT INTO duties (Code, Institution, title) VALUES (2, 'Gosh', 'referee');
INSERT INTO duties (Code, Institution, title) VALUES (3, 'Tumo', 'player');
INSERT INTO duties (Code, Institution, title) VALUES (4, 'Riwa', 'player');
INSERT INTO duties (Code, Institution, title) VALUES (5, 'Zilo', 'player');
*/


--Update records (example:Update a game name)

/*
USE sports;
UPDATE games SET Game = 'swimming' WHERE Code = 5;
*/


--Delete records (Example:Delete a duty record)

/*
USE sports;
DELETE FROM duties WHERE Code = 5;
*/


--Select all records from 'games' table:

/*
USE sports;
SELECT * FROM games;
*/
